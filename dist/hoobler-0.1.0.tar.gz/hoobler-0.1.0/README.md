# Hoobler - Assistente I.A.

Assistente I.A. Chatbot com foco em automatização de tarefas no PC.
Uma espécie de CMD++, intergrado com o prompt de comando/terminal via CLI e também possuindo uma
versão TUI com suporte a mouse e sendo mais agradável aos olhos.
